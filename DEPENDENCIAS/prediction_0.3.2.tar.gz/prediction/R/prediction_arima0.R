#' @rdname prediction
#' @export
prediction.arima0 <- prediction.ar
