library("testthat")

test_check("svDialogs")
