library("testthat")

test_check("svMisc")
