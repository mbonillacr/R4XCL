library(testthat)
library(raster)
library(terra)

test_check("terra")
