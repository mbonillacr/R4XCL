#' alcohol
#'
#' Data loads lazily. Type data(alcohol) into the console.
#'
#' @docType data
#'
#' @usage data(alcohol)
#'
#' @format A data.frame with 9822 rows and 33 variables:
#' \itemize{
#'  \item abuse. =1 if abuse alcohol
#'  \item status. out of workforce = 1; unemployed = 2, employed = 3
#'  \item unemrate. state unemployment rate
#'  \item age. age in years
#'  \item educ. years of schooling
#'  \item married. =1 if married
#'  \item famsize. family size
#'  \item white. =1 if white
#'  \item exhealth. =1 if in excellent health
#'  \item vghealth. =1 if in very good health
#'  \item goodhealth. =1 if in good health
#'  \item fairhealth. =1 if in fair health
#'  \item northeast. =1 if live in northeast
#'  \item midwest. =1 if live in midwest
#'  \item south. =1 if live in south
#'  \item centcity. =1 if live in central city of MSA
#'  \item outercity. =1 if in outer city of MSA
#'  \item qrt1. =1 if interviewed in first quarter
#'  \item qrt2. =1 if interviewed in second quarter
#'  \item qrt3. =1 if interviewed in third quarter
#'  \item beertax. state excise tax, $ per gallon
#'  \item cigtax. state cigarette tax, cents per pack
#'  \item ethanol. state per-capita ethanol consumption
#'  \item mothalc. =1 if mother an alcoholic
#'  \item fathalc. =1 if father an alcoholic
#'  \item livealc. =1 if lived with alcoholic
#'  \item inwf. =1 if status > 1
#'  \item employ. =1 if employed
#'  \item agesq. age^2
#'  \item beertaxsq. beertax^2
#'  \item cigtaxsq. cigtax^2
#'  \item ethanolsq. ethanol^2
#'  \item educsq. educ^2
#' }
#' @source \url{https://www.cengage.com/cgi-wadsworth/course_products_wp.pl?fid=M20b&product_isbn_issn=9781111531041}
#' @examples  str(alcohol)
"alcohol"
 
 
