#' crime1
#'
#' Data loads lazily. Type data(crime1) into the console.
#'
#' @docType data
#'
#' @usage data(crime1)
#'
#' @format A data.frame with 2725 rows and 16 variables:
#' \itemize{
#'  \item narr86. # times arrested, 1986
#'  \item nfarr86. # felony arrests, 1986
#'  \item nparr86. # property crme arr., 1986
#'  \item pcnv. proportion of prior convictions
#'  \item avgsen. avg sentence length, mos.
#'  \item tottime. time in prison since 18 (mos.)
#'  \item ptime86. mos. in prison during 1986
#'  \item qemp86. # quarters employed, 1986
#'  \item inc86. legal income, 1986, $100s
#'  \item durat. recent unemp duration
#'  \item black. =1 if black
#'  \item hispan. =1 if Hispanic
#'  \item born60. =1 if born in 1960
#'  \item pcnvsq. pcnv^2
#'  \item pt86sq. ptime86^2
#'  \item inc86sq. inc86^2
#' }
#' @source \url{https://www.cengage.com/cgi-wadsworth/course_products_wp.pl?fid=M20b&product_isbn_issn=9781111531041}
#' @examples  str(crime1)
"crime1"
 
 
