#' fish
#'
#' Data loads lazily. Type data(fish) into the console.
#'
#' @docType data
#'
#' @usage data(fish)
#'
#' @format A data.frame with 97 rows and 20 variables:
#' \itemize{
#'  \item prca. price for Asian buyers
#'  \item prcw. price for white buyers
#'  \item qtya. quantity sold to Asians
#'  \item qtyw. quantity sold to whites
#'  \item mon. =1 if Monday
#'  \item tues. =1 if Tuesday
#'  \item wed. =1 if Wednesday
#'  \item thurs. =1 if Thursday
#'  \item speed2. min past 2 days wind speeds
#'  \item wave2. avg max last 2 days wave height
#'  \item speed3. 3 day lagged max windspeed
#'  \item wave3. avg max wave hghts of 3 & 4 day lagged hghts
#'  \item avgprc. ((prca*qtya) + (prcw*qtyw))/(qtya + qtyw)
#'  \item totqty. qtya + qtyw
#'  \item lavgprc. log(avgprc)
#'  \item ltotqty. log(totqty)
#'  \item t. time trend
#'  \item lavgp_1. lavgprc[_n-1]
#'  \item gavgprc. lavgprc - lavgp_1
#'  \item gavgp_1. gavgprc[_n-1]
#' }
#' @source \url{https://www.cengage.com/cgi-wadsworth/course_products_wp.pl?fid=M20b&product_isbn_issn=9781111531041}
#' @examples  str(fish)
"fish"
 
 
