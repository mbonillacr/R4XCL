library(testthat)
library(wooldridge)

test_check("wooldridge")
