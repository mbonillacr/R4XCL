CAIC <-
function (object, ..., alpha) 
UseMethod("CAIC")
