makeUsedAvail <-
function(x, ...) UseMethod("makeUsedAvail")
