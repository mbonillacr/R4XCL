mep <-
function (object, ...)
    UseMethod("mep")
