model.frame.rsf <-
function (formula, ...)
{
    formula$model
}

