mFilter  0.1-4
==============

-   2018-09-22  Minor fixes for new R versions.

 
