library("testthat")
library("margins")
test_check("margins")
