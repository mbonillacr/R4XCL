fx_carga_factura = function(pfXML)
{
  lRet = list()
  lRet$valido = T
  lRet$mensaje = ""
  lRet$datos = data.frame()
  lRet$tipoFactura = ""
  
  tryCatch( 
    expr = {
      # remueve caracteres extras antes de la declaracion de XML
      cnxXML = readr::read_lines(file = pfXML, n_max = -1L)
      # cnxXML = readLines(con = pfXML, warn = F, encoding = "UTF-8")
      
      pXML = gsub("[\x01-\x1f\x7f-\xff]", "", cnxXML) 
      pXML = substr(pXML, start = gregexpr(pattern =  "<?xml", text = pXML, fixed =  T) , stop = nchar(pXML))
      pXML = paste(pXML, collapse = '')
      
      vXMLFactura = xml2::as_list(xml2::read_xml(x = pXML))
      
      # Parser de Factura hacer funcion
      if (xml2::xml_name(x = xml2::as_xml_document(vXMLFactura)) == "FacturaElectronica")
      {
        # Mapeo
        vProveedor = vXMLFactura$FacturaElectronica$Emisor$Nombre
        vNumero = vXMLFactura$FacturaElectronica$NumeroConsecutivo
        ## Factura es FAC y Nota de Credito es NC
        vTipoDocumento = "FAC"
        vFechaDocumento =  format(as.Date(substr(vXMLFactura$FacturaElectronica$FechaEmision,0,10)), format = "%m-%d-%Y") 
        #duda si es el vence
        vFechaRige =  format(as.Date(substr(vXMLFactura$FacturaElectronica$FechaEmision,0,10)), format = "%m-%d-%Y") 
        # Proveedor - y agregar detalle de todos los items para edición
        vAplicacion = paste0(vProveedor, " - ",
                             paste(
                               xml2::xml_find_all(x =  xml2::as_xml_document(vXMLFactura), xpath =  ".//Cantidad") %>% xml2::xml_text(1), 
                               xml2::xml_find_all(x =  xml2::as_xml_document(vXMLFactura), xpath =".//Detalle") %>% xml2::xml_text(1),
                               collapse = " | ", sep = " "))
        vMonto = as.double(vXMLFactura$FacturaElectronica$ResumenFactura$TotalComprobante)
        vSubTotal = as.double(vXMLFactura$FacturaElectronica$ResumenFactura$TotalVenta)
        
        if(is.null(vXMLFactura$FacturaElectronica$ResumenFactura$TotalDescuentos)){
          vDescuento = 0
        }else {
          vDescuento = as.double(vXMLFactura$FacturaElectronica$ResumenFactura$TotalDescuentos)
        }
        
        if(is.null(vXMLFactura$FacturaElectronica$ResumenFactura$TotalImpuesto)) {
          vImpuesto1 = 0
        } else {
          vImpuesto1 = as.double(vXMLFactura$FacturaElectronica$ResumenFactura$TotalImpuesto)
        }
        vImpuesto2 = 0
        vRubro1 = 0
        vRubro2 = 0 
        # 0 si es de contado y cantidad de dias si no
        if(vXMLFactura$FacturaElectronica$CondicionVenta == "01")
        {
          vCondicionPago = 0
        } else if(vXMLFactura$FacturaElectronica$CondicionVenta == "02"){
          vCondicionPago = as.integer(vXMLFactura$FacturaElectronica$PlazoCredito)
        }else if(vXMLFactura$FacturaElectronica$CondicionVenta == "99"){
          vCondicionPago = 0
        }
        
        vMoneda = vXMLFactura$FacturaElectronica$ResumenFactura$CodigoTipoMoneda$CodigoMoneda
        # user el tipo FAC o NC
        vSubtipoDocumento = vTipoDocumento
        
        # CREOO, valdiar con WENDY
        if(vXMLFactura$FacturaElectronica$CondicionVenta == "01")
        {
          vFechaVence = vFechaDocumento
        } else if(vXMLFactura$FacturaElectronica$CondicionVenta == "02"){
          vFechaVence = format(as.Date(substr(vXMLFactura$FacturaElectronica$FechaEmision,0,10))  + as.integer(vXMLFactura$FacturaElectronica$PlazoCredito), format = "%m-%d-%Y")
        }  else if(vXMLFactura$FacturaElectronica$CondicionVenta == "99"){
          vFechaVence = vFechaDocumento
        }
        
        lRet$datos = data.frame(
          vProveedor,
          vNumero,
          vTipoDocumento,
          vFechaDocumento,
          vFechaRige,
          vAplicacion,
          vMonto,
          vSubTotal,
          vDescuento,
          vImpuesto1,
          vImpuesto2,
          vRubro1,
          vRubro2,
          vCondicionPago,
          vMoneda,
          vSubtipoDocumento,
          vFechaVence,
          stringsAsFactors =  F
        )
        
        colnames(lRet$datos) = colnames(dfDatosFactura)
        
        lRet$valido = T
        lRet$mensaje = "Factura Generado con éxito"
        lRet$tipoFactura = "Factura Electrónica"
        
      } else if(xml2::xml_name(x = xml2::as_xml_document(vXMLFactura)) == "NotaCreditoElectronica")
      {
        
        vProveedor = vXMLFactura$FacturaElectronica$Emisor$Nombre
        vNumero = vXMLFactura$FacturaElectronica$NumeroConsecutivo
        ## Factura es FAC y Nota de Credito es NC
        vTipoDocumento = "NC"
        vFechaDocumento =  format(as.Date(substr(vXMLFactura$FacturaElectronica$FechaEmision,0,10)), format = "%m-%d-%Y") 
        #duda si es el vence
        vFechaRige =  format(as.Date(substr(vXMLFactura$FacturaElectronica$FechaEmision,0,10)), format = "%m-%d-%Y") 
        # Proveedor - y agregar detalle de todos los items para edición
        vAplicacion = paste0(vProveedor, " - ",
                             paste(
                               xml2::xml_find_all(x =  xml2::as_xml_document(vXMLFactura), xpath =  ".//Cantidad") %>% xml2::xml_text(1), 
                               xml2::xml_find_all(x =  xml2::as_xml_document(vXMLFactura), xpath =".//Detalle") %>% xml2::xml_text(1),
                               collapse = " | ", sep = " "))
        vMonto = as.double(vXMLFactura$FacturaElectronica$ResumenFactura$TotalComprobante)
        vSubTotal = as.double(vXMLFactura$FacturaElectronica$ResumenFactura$TotalVenta)
        
        if(is.null(vXMLFactura$FacturaElectronica$ResumenFactura$TotalDescuentos))
          vDescuento = 0
        else 
          vDescuento = as.double(vXMLFactura$FacturaElectronica$ResumenFactura$TotalDescuentos)
        
        if(is.null(vXMLFactura$FacturaElectronica$ResumenFactura$TotalImpuestos))
          vImpuesto1 = 0
        else 
          vImpuesto1 = as.double(vXMLFactura$FacturaElectronica$ResumenFactura$TotalImpuesto)
        vImpuesto2 = 0
        vRubro1 = 0
        vRubro2 = 0 
        # 0 si es de contado y cantidad de dias si no
        if(vXMLFactura$FacturaElectronica$CondicionVenta == "01")
        {
          vCondicionPago = 0
        } else if(vXMLFactura$FacturaElectronica$CondicionVenta == "02"){
          vCondicionPago = as.integer(vXMLFactura$FacturaElectronica$PlazoCredito)
        }else if(vXMLFactura$FacturaElectronica$CondicionVenta == "99"){
          vCondicionPago = 0
        }
        
        vMoneda = vXMLFactura$FacturaElectronica$ResumenFactura$CodigoTipoMoneda$CodigoMoneda
        # user el tipo FAC o NC
        vSubtipoDocumento = vTipoDocumento
        
        # CREOO, valdiar con WENDY
        if(vXMLFactura$FacturaElectronica$CondicionVenta == "01")
        {
          vFechaVence = vFechaDocumento
        } else if(vXMLFactura$FacturaElectronica$CondicionVenta == "02"){
          vFechaVence = format(as.Date(substr(vXMLFactura$FacturaElectronica$FechaEmision,0,10))  + as.integer(vXMLFactura$FacturaElectronica$PlazoCredito), format = "%m-%d-%Y")
        }  else if(vXMLFactura$FacturaElectronica$CondicionVenta == "99"){
          vFechaVence = vFechaDocumento
        }
        
        lRet$datos = data.frame(
          vProveedor,
          vNumero,
          vTipoDocumento,
          vFechaDocumento,
          vFechaRige,
          vAplicacion,
          vMonto,
          vSubTotal,
          vDescuento,
          vImpuesto1,
          vImpuesto2,
          vRubro1,
          vRubro2,
          vCondicionPago,
          vMoneda,
          vSubtipoDocumento,
          vFechaVence,
          stringsAsFactors =  F
        )
        
        lRet$valido = T
        lRet$mensaje = "Nota de Crédito Generado con éxito"
        lRet$tipoFactura = "Nota de Crédito Electrónica"
        
        colnames(lRet$datos) = colnames(dfDatosFactura)
        
      }else {
        
        lRet$valido = F
        lRet$mensaje = "No corresponde a Factura o Nota de Crédito Electrónica"
        lRet$tipoFactura = "No Procesable"
      }
      
      lRet$datos
      
    },
    
    error = function(e) {warning( paste("Error en lecutra del  xml ",pfXML, e ) )}
    
  )
  lRet$datos
  
}
