XT_ParserXML <- function(pDirectorio=NULL)
  
{
  
  #-------------------------->>>   
  # [0] LIBRERIAS  
  #-------------------------->>>
  
    library(methods)
    library(xml2)
    library(openxlsx)
    library(dplyr)
    library(stringr)
    library(data.table)

  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  
    DIR_ORIG       = "~/BERT2/functions/"
    FUNCIONES      = paste0(DIR_ORIG,"InternoFunciones.R")
    TABLA          = paste0(DIR_ORIG,"InternoEstructuraTabla.R")
  
    source(file.path(FUNCIONES))
    source(file.path(TABLA))
  
    facturas      = 0
    notasCredito  = 0
    noProcesables = 0
  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
    xmls = list.files(path = pDirectorio)
    xmls = sort(xmls)
    
    for (i in xmls){
                    print(paste0(pDirectorio,"/",i))
                    
                    df = fx_carga_factura(paste0(pDirectorio,"/",i))
              
                    if(!(is.data.frame(df) && nrow(df)==0)){
                      dfDatosFactura = unique(rbindlist(list(dfDatosFactura, df)), by = 'Numero')
                      }
                    }
    cat(
        paste(
              "Archivos Totales: ", length(xmls),
              "\nFacturas Electronicas Procesadas: ", facturas,
              "\nNotas de Credito Electronicas Procesadas: ", notasCredito,
              "\nArchivos no procesables: ", noProcesables
              )
          )
    
  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
    #pNombreOutput=paste0("Facturas Procesadas mes:", pMes, "xlsx")
    #openxlsx::write.xlsx(x = dfDatosFactura, file = pNombreOutput)
  
  #_________________________________________________________________   
  # [4] RESULTADO FINAL
  #_________________________________________________________________
  
    return(dfDatosFactura)
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

Detalle = "Carga los archivos XML desde una ruta establecida, procesandolos en una tabla resultante"

attr(XT_ParserXML, "description") = 
  list(
        Detalle,
        pDirectorio="Ruta del directorio que contiene los archivos XML a cargar"
       )