#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# ANALISIS DE COMPONENTES PRINCIPALES                  +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

AD_ACP <- function(SetDatosX, 
                   TipoOutput=0, 
                   SetDatosPredecir)
  
{
  library(corrplot)

  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  

  DIR_ORIG = "~/BERT2/functions/"
  ARCHIVO  = paste0(DIR_ORIG,"R4XCL-INTERNO.R")
  FUENTE01 = file.path(ARCHIVO)
  source(FUENTE01)

  DT = R4XCL_INT_DATOS(SetDatosX)
  DT = data.frame(DT)
  P  = ncol(DT)
  DT = matrix(as.numeric(unlist(DT)), nrow=nrow(DT), ncol=P)
  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
  Cor.Datos = cor(DT)
  res.pca   = princomp(DT, cor=T)

  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
  if (TipoOutput == 0){

      OutPut = corrplot(Cor.Datos,
                        type="upper",
                        order="hclust",
                        tl.col="black",
                        tl.srt=45)
      
  }else if(TipoOutput == 1){
    
    OutPut = res.pca$loadings
  
  }else if(TipoOutput == 2.0){ 
  
    #:::::::::::::::::::::::::::::::    
    # Coordenadas de Individuos
    #:::::::::::::::::::::::::::::::
      
    OutPut =  res.pca$scores
 
  }else if(TipoOutput == 2.1){ 
    
    #:::::::::::::::::::::::::::::::    
    # COS^2 de Individuos
    #:::::::::::::::::::::::::::::::
    
    # PCA center of gravity
    getd2 = function(x_i, center, scale){return(sum(((x_i-center)/scale)^2))}
    
    # 2. Compute the cos2. The sum of each row is 1
    x_i   = res.pca$scores
    
    cos2  = function(x_i, d2){return(x_i^2/d2)}
    
    center= res.pca$center
    scale = res.pca$scale
    
    d2    = apply(DatosX,1,getd2, center, scale)
    
    OutPut= apply(x_i, 2, cos2, d2)
    
  }else if(TipoOutput == 2.2){   
    
    #:::::::::::::::::::::::::::::::
    # Contribucion de individuos
    #:::::::::::::::::::::::::::::::
    
    x_i   = res.pca$scores
    
    contrib <- function(x_i, comp.sdev, n.ind){100*(1/n.ind)*x_i^2/comp.sdev^2}
    
    OutPut = t(apply(x_i, 1, contrib, res.pca$sdev, nrow(x_i)))    
       
  }else if(TipoOutput == 3.0){  
    
    #:::::::::::::::::::::::::::::::    
    # Coordenadas de Variables
    #:::::::::::::::::::::::::::::::
    
    OutPut = cbind("Valores Propios"=res.pca$sdev^2,
                   "Aporte a la Varianza"=res.pca$sdev^2/sum(res.pca$sdev^2),
                   "Aporte Acumulado"=cumsum(res.pca$sdev^2/sum(res.pca$sdev^2)))
 
  }else if(TipoOutput == 3.1){    

    #:::::::::::::::::::::::::::::::    
    # COS^2 de variables
    #:::::::::::::::::::::::::::::::
        
    var_coord_func <- function(loadings, comp.sdev){loadings*comp.sdev}
    
    loadings  <- res.pca$loadings
    sdev      <- res.pca$sdev
    var.coord <- t(apply(loadings, MARGIN = 1, var_coord_func, sdev)) 
    OutPut    <- var.coord^2
    
  }else if(TipoOutput == 3.2){     
    
    #:::::::::::::::::::::::::::::::
    # Contribucion de variables
    #:::::::::::::::::::::::::::::::

    contrib   <- function(var.cos2, comp.cos2){var.cos2*100/comp.cos2}
    var_coord_func <- function(loadings, comp.sdev){loadings*comp.sdev}
        
    loadings  <- res.pca$loadings
    sdev      <- res.pca$sdev
    var.coord <- t(apply(loadings, MARGIN = 1, var_coord_func, sdev)) 
    var.cos2  <- var.coord^2 
    comp.cos2 <- apply(var.cos2, MARGIN = 2, FUN = sum)

    OutPut    <- t(apply(var.cos2, MARGIN = 1, contrib, comp.cos2))
    
  }else if(TipoOutput == 4){  
    
    if(missing(SetDatosPredecir)){
      
      OutPut = res.pca$scores
      
    }else{
      
      DatosX = SetDatosPredecir[-1,]
      
      DatosX = matrix(as.numeric(DatosX), nrow=nrow(DatosX), ncol=p)
      DatosX = data.frame(DatosX)
      colnames(DatosX)[1:p]=nombresX[1:p]
      
      A = predict(res.pca, newdata = ind.sup)
      OutPut=data.frame("R4XCL_PrediccionFueraDeMuestra"= A)
      
    } 
    
  }else if(TipoOutput == 5){    
    
    biplot(res.pca, scale = 0)
    OutPut="Biplot Ejecutado"
       
  }else if(TipoOutput >= 6){   
        
    OutPut = "Revisar par�metros disponibles" 
    
  }  
  
  #_________________________________________________________________   
  # [4] RESULTADO FINAL
  #_________________________________________________________________
  
  return(OutPut)
  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

Detalle = "Realiza el An�lisis de Componentes Principales (ACP)"

attr(AD_ACP, "description") = 
  list(Detalle,
       SetDatosX = "Datos por Analizar",
       TipoOutput= "0:Matriz de Correlaci�n, 1:Coordenadas: Variables, 2.0:Coordenadas: Individuos, 2.1: COS^2: INDs, 2.2: Contribuci�n:INDs, 3.0: Valores Propios, 3.1: COS^2: VARs, 3.2: Contribuci�n:VARs, 4: Predicci�n, 5: Grafico VARs|INDs",
       SetDatosPredecir= "Computar datos fuera de muestra")

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# ALGORITMO DE K MEDIAS                                +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

AD_KMedias <- function(SetDatosX, K=3, Semilla=123456,Metodo=1, TipoOutput=0, SetDatosPredecir)
  
{
  library(corrplot)
  
  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  
  DIR_ORIG = "~/BERT2/functions/"
  ARCHIVO  = paste0(DIR_ORIG,"R4XCL-INTERNO.R")
  FUENTE01 = file.path(ARCHIVO)
  source(FUENTE01)
  
  DT = R4XCL_INT_DATOS(SetDatosX)
  DT = data.frame(DT)
  P  = ncol(DT)
  DT = matrix(as.numeric(unlist(DT)), nrow=nrow(DT), ncol=P)
  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
  set.seed(Semilla)
  
  Metodos  = c("Hartigan-Wong", "Lloyd", "Forgy","MacQueen")
  res.kmns = kmeans(
                    DT,
                    center= K,
                    algorithm = Metodos[1][Metodo]
                    )

  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
  if (TipoOutput == 0){
    
    A=res.kmns$cluster
    OutPut = data.frame("Cluster Asignado" = A)
    
  }else if(TipoOutput == 1){
    
    A = res.kmns$centers
    nombresX = paste0(SetDatosX[1,1:P])
    colnames(A)=nombresX
    OutPut=data.frame("Centros"= A )
    
  }else if(TipoOutput == 2){   

    OutPut = data.frame(
                        "Cluster"=seq(1:K),
                        "Variabilidad Dentro del Cluster" = res.kmns$withinss,
                        "N en cada cluster" = res.kmns$size
                        )
            
  }else if(TipoOutput == 3){
    
    OutPut= rbind(
                  "Variabilidad TOTAL"=res.kmns$totss,
                  "Variabilidad TOTAL intra clases"=res.kmns$tot.withinss,
                  "Variabilidad TOTAL entre clases"=res.kmns$betweenss
                  )

  }else if(TipoOutput == 4){
    
    if(missing(SetDatosPredecir)){
      
      OutPut = res.kmns$cluster
      
    }else{
      
      nombresX = paste0(SetDatosPredecir[1,1:P])
      DatosX = SetDatosPredecir[-1,]
  
      DatosX = matrix(as.numeric(DatosX), nrow=nrow(DatosX), ncol=P)
      DatosX = data.frame(DatosX)
      
      colnames(DatosX)[1:P] = nombresX[1:P]

      centers   <- data.frame(res.kmns$centers)
      colnames(centers)=nombresX[1:P]

      dist_mat  <- as.matrix(dist(rbind(centers, DatosX)))
      dist_mat  <- dist_mat[-seq(K), seq(K)]
      A = max.col(-dist_mat)
      
      OutPut=data.frame("R4XCL_PrediccionFueraDeMuestra"= A)
      
    } 

  }else if(TipoOutput >= 5){   
    
    OutPut = "Revisar par�metros disponibles" 
    
  }  
  
  #_________________________________________________________________   
  # [4] RESULTADO FINAL
  #_________________________________________________________________
  
  return(OutPut)
  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

Detalle = "Analisis de conglomerados (K-Medias)"

attr(AD_KMedias, "description") = 
  list(Detalle,
       SetDatosX = "Datos por Analizar",
       K= "Cantidad de Clusters requeridos",
       Semilla= "Valor de generaci�n aleatoria (ej:123456)",
       Metodo= "1:Hartigan-Wong, 2:Lloyd, 3:Forgy, 4:MacQueen",
       TipoOutput="0:Cluster Asignado, 1:Centros, 2:Variabilidad intra clases, 3:Variabilidad Total, 4:Predecir",
       SetDatosPredecir= "Computar datos fuera de muestra")