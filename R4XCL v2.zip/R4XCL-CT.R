MR_Lineal = function(SetDatosX, 
                     SetDatosY,
                     TipoOutput=0, 
                     SetDatosPredecir=NULL)
{
  
  library(margins)
  library(stargazer)
  library(sandwich)
  library(zoo)
  library(vctrs)
  library(lmtest)
  library(curl)
  library(rlang)
  library(data.table)

  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  
  DIR_ORIG = "~/BERT2/functions/"
  ARCHIVO  = paste0(DIR_ORIG,"R4XCL-INTERNO.R")
  FUENTE01 = file.path(ARCHIVO)
  source(FUENTE01)
  
  FX = R4XCL_INT_FUNCION(SetDatosX,SetDatosY)
  DT = R4XCL_INT_DATOS(SetDatosX,SetDatosY)
  DT = data.frame(DT)
  P  = ncol(DT)

  Datos = tidyr::unnest(DT, c(1:P))
  especificacion = eval(parse(text=FX))

  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
  Modelo = lm(formula = especificacion, data = Datos)
  Y_Pred = Modelo$fitted.values
  
  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
  if (TipoOutput == 0){
    
    OutPut = data.frame("R4XCL_ModeloEstimado"= capture.output(stargazer(Modelo, type="text", ci=TRUE, ci.level=0.95,single.row=TRUE)))
    
  }else if(TipoOutput == 1){
    
    OutPut = data.frame("R4XCL_PrediccionDentroDeMuestra"= Y_Pred)
    
  }else if(TipoOutput == 2){ 
    
    if(missing(SetDatosPredecir))
      
    {OutPut = data.frame("R4XCL_PrediccionDentroDeMuestra"= Y_Pred)
    
    }else{
      
      p        = ncol(SetDatosPredecir)
      nombresX = paste0(SetDatosX[1,1:p])
      
      SetDatosPredecir = SetDatosPredecir[-1,]
      SetDatosPredecir = matrix(as.numeric(SetDatosPredecir), nrow=nrow(SetDatosPredecir)-1, ncol=p)
      SetDatosPredecir = data.frame(SetDatosPredecir)
      
      colnames(SetDatosPredecir)[1:p]=nombresX[1:p]
      
      A = predict(Modelo, newdata = SetDatosPredecir)
      OutPut=data.frame("R4XCL_PrediccionFueraDeMuestra"= A)
    }
    
  }else if(TipoOutput == 3){
    
    OutPut=sapply(marginal_effects(Modelo, Datos),mean)
    OutPut=data.frame("R4XCL_EfectosMarginales"= capture.output(OutPut))
    
  }else if(TipoOutput == 4){  
    
    OutPut=car::vif(Modelo) 
    OutPut=data.frame("R4XCL_InflacionDeVarianza"= OutPut)
    
  }else if(TipoOutput == 5){  
    
    OutPut=lmtest::bptest(Modelo) 
    OutPut=data.frame("R4XCL_Heterocedasticidad"=capture.output(OutPut))    
    
  }else if(TipoOutput == 6){    
    
    cov <- sandwich::vcovHC(Modelo, type = "HC")
    
    robust.se <- sqrt(diag(cov))
    
    OutPut=stargazer(Modelo, Modelo, 
                     se=list(NULL, robust.se),
                     column.labels=c("OLS","OLS E.S. Robusto"), 
                     type="text",
                     align=TRUE)  
    
  }else if(TipoOutput == 7){ 
    
    A=influence.measures(Modelo)
    OutPut=data.frame("R4XCL_ObservacionesDeInfluencia"=A$is.inf)
    
  }else if(TipoOutput > 7){   
    
    OutPut = "Revisar par�metros disponibles"
    
  }  
  
  #-------------------------->>> 
  # [4] RESULTADO FINAL
  #-------------------------->>> 

  return(OutPut)  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

Detalle = "Estima un modelo de regresi�n lineal"

attr(MR_Lineal, "description") = 
  list(
   Detalle,
   SetDatosX = "Variables INDEPENDIENTES",
   SetDatosY = "Variables DEPENDIENTES",
   TipoOutput= "0:Modelo, 1:Y Estimado, 2:Predicci�n, 3:Efectos Marginales, 4: Test Multicolinealidad, 5: Test Heterocedasticidad, 6: Estimación Robusta",
   SetDatosPredecir= "Computar datos fuera de muestra")

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# MODELO BINARIO                                       +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++


MR_Binario = function(SetDatosX, 
                      SetDatosY,
                      TipoModelo=0, 
                      TipoOutput=0, 
                      SetDatosPredecir=NULL)
{
  
  library(ResourceSelection)
  library(margins)
  library(mboost)
  
  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  
  DIR_ORIG = "~/BERT2/functions/"
  ARCHIVO  = paste0(DIR_ORIG,"R4XCL-INTERNO.R")
  FUENTE01 = file.path(ARCHIVO)
  source(FUENTE01)
  
  FX = R4XCL_INT_FUNCION(SetDatosX,SetDatosY)
  DT = R4XCL_INT_DATOS(SetDatosX,SetDatosY)
  DT = data.frame(DT)
  P  = ncol(DT)
  
  Datos = tidyr::unnest(DT, c(1:P))
  especificacion = eval(parse(text=FX))
  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
  pModelo=ifelse(TipoModelo==0,"logit","probit")
  Modelo = glm(formula = especificacion, data = Datos, family = binomial(link = pModelo))
  Y_Pred = Modelo$fitted.values
               
   #-------------------------->>> 
   # [3] PREPARACION DE RESULTADOS
   #-------------------------->>> 
   
  if (TipoOutput == 0){
     
    OutPut = data.frame("R4XL_ModeloEstimado"= capture.output(summary(Modelo)))
     
  }else if(TipoOutput == 1){
     
    OutPut = data.frame("R4XL_PrediccionEnMuestra"= Y_Pred)
     
  }else if(TipoOutput == 2){    
     
    if(missing(SetDatosPredecir))
      
    {OutPut = data.frame("R4XCL_PrediccionDentroDeMuestra"= Y_Pred)
    
    }else{
      
      p        = ncol(SetDatosPredecir)
      nombresX = paste0(SetDatosX[1,1:p])
      SetDatosPredecir = SetDatosPredecir[-1,]
      
      SetDatosPredecir = matrix(as.numeric(SetDatosPredecir), nrow=nrow(SetDatosPredecir), ncol=p)
      SetDatosPredecir = data.frame(SetDatosPredecir)
      
      colnames(SetDatosPredecir)[1:p]=nombresX[1:p]
      
      A = predict(Modelo, newdata = SetDatosPredecir, type = "response")
      OutPut=data.frame("R4XCL_PrediccionFueraDeMuestra"= A)
    }
     
  }else if(TipoOutput == 3){ 

    DatosY = as.numeric(DT[,1])

    HL     = ResourceSelection::hoslem.test(DatosY, Y_Pred, 10)
    HL     = cbind(HL$expected,HL$observed,"HL"=HL$statistic,Prob=HL$p.value)
    OutPut = data.frame("R4XL_TestDeHosmerLemeshow"=  data.frame(HL) )
    
  }else if(TipoOutput == 4){
     
    OutPut = sapply(marginal_effects(Modelo, Datos),mean)
    OutPut = data.frame("R4XL_EfectosMarginales"= capture.output(OutPut))
  
  }else if(TipoOutput == 5){   
  
    A = anova(Modelo, test = 'Chisq')
    OutPut = data.frame("R4XL_ANOVA" = A)

  }else if(TipoOutput > 5){      
    
    OutPut = "Revisar par�metros disponibles" 
     
  } 
   #-------------------------->>> 
   # [4] RESULTADO FINAL
   #-------------------------->>> 

  return(OutPut)  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++
Detalle = "Estima un modelo de regresi�n para variable binaria ( Y = {0,1} )"

attr(MR_Binario, "description" ) = 
  list( 
   Detalle,
   SetDatosX       = "Variables INDEPENDIENTES",
   SetDatosY       = "Variables DEPENDIENTES",
   TipoModelo      = "0:Logit, 1:Probit",
   TipoOutput      = "0:Modelo, 1:Prob Estimada, 2:Prediccion, 3:Test HL, 4:Efectos Marginales",
   SetDatosPredecir= "Computar probabilidad a datos fuera de muestra"
  )
####### 

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# MR_Poisson                                           +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

MR_Poisson = function(SetDatosX, 
                      SetDatosY, 
                      TipoOutput=0, 
                      SetDatosPredecir=NULL)
  
  #https://stats.idre.ucla.edu/r/dae/poisson-regression/
{
  
  library(ResourceSelection)
  library(sandwich)
  library(margins)
  
  #http://statistics.ats.ucla.edu/stat/r/dae/logit.htm
  
  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  
  DIR_ORIG = "~/BERT2/functions/"
  ARCHIVO  = paste0(DIR_ORIG,"R4XCL-INTERNO.R")
  FUENTE01 = file.path(ARCHIVO)
  source(FUENTE01)
  
  FX = R4XCL_INT_FUNCION(SetDatosX,SetDatosY)
  DT = R4XCL_INT_DATOS(SetDatosX,SetDatosY)
  DT = data.frame(DT)
  P  = ncol(DT)
  
  Datos = tidyr::unnest(DT, c(1:P))
  especificacion = eval(parse(text=FX))
  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
  Modelo     <- glm(formula = especificacion, family = "poisson", data = Datos);
  Y_Pred     <- predict(Modelo, type="response")
  cov.Modelo <- sandwich::vcovHC(Modelo, type="HC0")
  std.err    <- sqrt(diag(cov.Modelo))

  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
  if (TipoOutput == 0){
    
    OutPut = data.frame("R4XCL_ModeloEstimado"= capture.output(stargazer(Modelo, type="text", ci=TRUE, ci.level=0.95,single.row=TRUE)))
    
  }else if(TipoOutput == 1){
    
    OutPut = data.frame("R4XCL_PrediccionEnMuestra"=Y_Pred)
    
  }else if(TipoOutput == 2){ 
    
    if(missing(SetDatosPredecir))
      
    {OutPut = data.frame("R4XCL_PrediccionDentroDeMuestra"= Y_Pred)
    
    }else{
      
      p        = ncol(SetDatosPredecir)
      nombresX = paste0(SetDatosX[1,1:p])
      SetDatosPredecir = SetDatosPredecir[-1,]
      
      SetDatosPredecir = matrix(as.numeric(SetDatosPredecir), nrow=nrow(SetDatosPredecir), ncol=p)
      SetDatosPredecir = data.frame(SetDatosPredecir)
      
      colnames(SetDatosPredecir)[1:p]=nombresX[1:p]
      
      A = predict(Modelo, newdata = SetDatosPredecir, type = "response")
      OutPut=data.frame("R4XCL_PrediccionFueraDeMuestra"= A)
    } 
    
  }else if(TipoOutput == 3){
    
    OutPut=sapply(marginal_effects(Modelo, Datos),mean)
    OutPut=data.frame("R4XCL_EfectosMarginales"= capture.output(OutPut))
    
  }else if(TipoOutput == 4){  
    
    OutPut=car::vif(Modelo) 
    OutPut=data.frame("R4XCL_InflacionDeVarianza"=OutPut)
    
    OutPut = cbind(
                  "Estimate"= coef(Modelo), 
                  "Robust SE" = std.err,
                  "Pr(>|z|)" = 2 * pnorm(abs(coef(Modelo)/std.err),lower.tail=FALSE),
                  "LL" = coef(Modelo) - 1.96 * std.err,
                  "UL" = coef(Modelo) + 1.96 * std.err
                  )
    
  }else if(TipoOutput == 5){  
    
    OutPut = with(Modelo, 
                    cbind(res.deviance = deviance, 
                          df = df.residual,
                          p = pchisq(deviance, df.residual, lower.tail=FALSE))
                  )
    
  }else if(TipoOutput > 5){   
    
    OutPut = "Revisar parámetros disponibles"
    
  }  
  
  #_________________________________________________________________   
  # [4] RESULTADO FINAL
  #_________________________________________________________________
  
  return(OutPut)
  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

Detalle = "Estima un modelo de regresión Poisson"

attr(MR_Poisson, "description") = 
  list(
   Detalle,
   SetDatosX       = "Variables INDEPENDIENTES",
   SetDatosY       = "Variables DEPENDIENTES",
   TipoOutput      = "0:Modelo, 1:Y Estimado, 2:Predicción, 3:Efectos Marginales, 4: Test Multicolinealidad, 5: Test Heterocedasticidad, 6: Estimación Robusta",
   SetDatosPredecir= "Computar datos fuera de muestra")

####### 

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# MR_Tobit                                             +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

MR_Tobit = function(SetDatosX, 
                    SetDatosY,
                    ValorTruncamiento=1,
                    DirTruncamiento,
                    TipoOutput=0, 
                    SetDatosPredecir=NULL)
{
  library(ResourceSelection)
  library(margins)
  library(VGAM)
  
  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  
  DIR_ORIG = "~/BERT2/functions/"
  ARCHIVO  = paste0(DIR_ORIG,"R4XCL-INTERNO.R")
  FUENTE01 = file.path(ARCHIVO)
  source(FUENTE01)
  
  FX = R4XCL_INT_FUNCION(SetDatosX,SetDatosY)
  DT = R4XCL_INT_DATOS(SetDatosX,SetDatosY)
  DT = data.frame(DT)
  P  = ncol(DT)

  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
    
  Datos = tidyr::unnest(DT, c(1:P))
  especificacion = eval(parse(text=FX))
  
  if(DirTruncamiento == 1){
    
    Modelo <- VGAM ::vglm(formula = especificacion, tobit(Upper = ValorTruncamiento), data = Datos)
    
  }else if (DirTruncamiento == -1){
    
    Modelo <- VGAM ::vglm(formula = especificacion, tobit(Lower = ValorTruncamiento), data = Datos)
    
  }
  
  Y_Pred = fitted(Modelo)[,1]
  
  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
  if (TipoOutput == 0){
    
    OutPut = data.frame("R4XL_ModeloEstimado"= capture.output(summary(Modelo)))
    
  }else if(TipoOutput == 1){
    
    OutPut = data.frame("R4XL_PrediccionEnMuestra"= Y_Pred)
    
  }else if(TipoOutput == 2){  
    
    if(missing(SetDatosPredecir))
      
    {OutPut = data.frame("R4XCL_PrediccionDentroDeMuestra"= Y_Pred)
    
    }else{
      
      p        = ncol(SetDatosPredecir)
      nombresX = paste0(SetDatosX[1,1:p])
      SetDatosPredecir = SetDatosPredecir[-1,]
      
      SetDatosPredecir = matrix(as.numeric(SetDatosPredecir), nrow=nrow(SetDatosPredecir), ncol=p)
      SetDatosPredecir = data.frame(SetDatosPredecir)
      
      colnames(SetDatosPredecir)[1:p]=nombresX[1:p]
      
      A = predict(Modelo, newdata = SetDatosPredecir, type = "response")
      OutPut=data.frame("R4XCL_PrediccionFueraDeMuestra"= A)
    } 
    
  }else if(TipoOutput > 2){      
    
    OutPut = "Revisar par�metros disponibles" 
    
  }
  
  #-------------------------->>> 
  # [4] RESULTADO FINAL
  #-------------------------->>> 
  
  return(OutPut)  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

Detalle = "Estima un modelo de regresion Tobit"
attr(MR_Tobit, "description" ) = 
  list( 
    Detalle,
    SetDatosX         = "Variables INDEPENDIENTES",
    SetDatosY         = "Variables DEPENDIENTES",
    ValorTruncamiento = "Valor umbral del truncamiento",   
    DirTruncamiento   = "-1: Truncamiento por la izquierda, 1: Truncamiento por la derecha",
    TipoOutput        = "0:Modelo, 1:Prob Estimada, 2:Prediccion, 3:Test HL, 4:Efectos Marginales",
    SetDatosPredecir  = "Computar probabilidad a datos fuera de muestra"
  )
####### 
