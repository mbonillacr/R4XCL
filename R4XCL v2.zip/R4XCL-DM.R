
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# ARBOLES DE DECISION                                  +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

AD_ArbolDeDecision <- function(SetDatosX, 
                               SetDatosY,
                               TipoOutput=0, 
                               SetDatosPredecir=NULL)
{
  
  library(rpart)
  library(readr)
  library(dplyr)
  library(rpart.plot)

  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  
  DIR_ORIG = "~/BERT2/functions/"
  ARCHIVO  = paste0(DIR_ORIG,"R4XCL-INTERNO.R")
  FUENTE01 = file.path(ARCHIVO)
  source(FUENTE01)
  
  FX = R4XCL_INT_FUNCION(SetDatosX,SetDatosY)
  especificacion = eval(parse(text=FX))

  DT = R4XCL_INT_DATOS(SetDatosX,SetDatosY)
  DT = data.frame(DT)
  P  = ncol(DT)
  N  = nrow(DT)

  Datos = tidyr::unnest(DT, c(1:P))
  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
  Modelo = rpart(especificacion, data=Datos)
  Y_Pred = predict(Modelo)
  
  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
  if (TipoOutput == 0){

    OutPut = "Ver Gr�fico"
    rpart.plot(Modelo)

  }else if(TipoOutput == 1){   
    
    OutPut = Modelo$split  
    
  }else if(TipoOutput == 2){   
  
    OutPut = Modelo$csplit  
  
  }else if(TipoOutput == 3){   
  
    OutPut = Modelo$cptable

  }else if(TipoOutput == 4){   
    
    OutPut = Modelo$frame   

  }else if(TipoOutput == 5){   
    
    OutPut = Modelo$where    
    
  }else if(TipoOutput == 6){   
    
    a = c("minsplit",Modelo$control$minsplit)
    b = c("minbucket",Modelo$control$minbucket)
    c = c("cp",Modelo$control$cp)
    d = c("maxcompete",Modelo$control$maxcompete)
    e = c("maxsurrogate",Modelo$control$maxsurrogate)
    f = c("surrogatestyle",Modelo$control$surrogatestyle)
    g = c("maxdepth",Modelo$control$maxdepth)
    h = c("xval",Modelo$control$xval)
    
    OutPut = rbind(a,b,c,d,e,f,g,h)
  
  }else if(TipoOutput == 7){ 
    
    if(missing(SetDatosPredecir)){
      
      OutPut = data.frame("R4XCL_PrediccionDentroDeMuestra"= Y_Pred)
    
    }else{

      DT = R4XCL_INT_DATOS(SetDatosPredecir)
      DT = data.frame(DT)
      P  = ncol(DT)
      N  = nrow(DT)
      Datos = tidyr::unnest(DT, c(1:P))

      A = predict(Modelo, newdata = Datos, type = "matrix")
      OutPut=data.frame("R4XCL_PrediccionFueraDeMuestra"= A)
      
    }  
    
  }else{   
  
    OutPut = "Revisar par�metros disponibles" 
    
  }  
  
  #_________________________________________________________________   
  # [4] RESULTADO FINAL
  #_________________________________________________________________
  
  return(OutPut)
  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

Detalle = "Estima un modelo de Arboles de Decision"

attr(AD_ArbolDeDecision, "description") = 
  list(
    Detalle,
    SetDatosX = "Variables INDEPENDIENTES",
    SetDatosY = "Variables DEPENDIENTES",
    TipoOutput= "0:Modelo, 1:Y Estimado, 2:Predicci�n, 3:Efectos Marginales, 4: Test Multicolinealidad, 5: Test Heterocedasticidad, 6: Estimación Robusta",
    SetDatosPredecir= "Computar datos fuera de muestra")

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# ANOVA FISHER                                         +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

RS_ANOVA = function(SetDatosY=NULL,
                   SetDatosX,
                   TipoOutput=0, 
                   SetDatosPredecir=NULL)
{
  
  library(margins)
  library(stargazer)
  library(sandwich)
  library(agricolae)
  library(tidyr)
  library(here)
  
  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  
  DIR_ORIG = "~/BERT2/functions/"
  ARCHIVO  = paste0(DIR_ORIG,"R4XCL-INTERNO.R")
  FUENTE01 = file.path(ARCHIVO)
  source(FUENTE01)
  
  FX = R4XCL_INT_FUNCION(SetDatosX,SetDatosY)
  DT = R4XCL_INT_DATOS(SetDatosX,SetDatosY)
  DT = data.frame(DT)
  P  = ncol(DT)
  
  DT1 = tidyr::unnest(DT, c(1:P))
  fx=eval(parse(text=FX))
  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
  Modelo = aov(fx, data = DT1)
  Y_Pred = Modelo$fitted.values 
  
  df<-df.residual(Modelo)
  MSerror<-deviance(Modelo)/df
  out <- with(DT1,LSD.test(DT1[,1],DT1[,2:P],df,MSerror))
  
  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
  if (TipoOutput == 0){
    
    OutPut = data.frame("R4XCL_ModeloEstimado"= capture.output(summary(Modelo)))
    
  }else if(TipoOutput == 1){
    
    OutPut = data.frame("R4XCL_PrediccionDentroDeMuestra"= Y_Pred)
    
  }else if(TipoOutput == 2){
    
    if(missing(SetDatosPredecir))
      
    {OutPut = data.frame("R4XCL_PrediccionDentroDeMuestra"= Y_Pred)
    
    }else{
      
      SetDatosPredecir = SetDatosPredecir[-1,]
      SetDatosPredecir = matrix(as.numeric(SetDatosPredecir), nrow=nrow(SetDatosPredecir)-1, ncol=p)
      SetDatosPredecir = data.frame(SetDatosPredecir)
      colnames(SetDatosPredecir)[1:p]=nombresX[1:p]
      
      A = predict(Modelo, newdata = SetDatosPredecir)
      OutPut=data.frame("R4XCL_PrediccionFueraDeMuestra"= A)
    }
    
  }else if(TipoOutput == 3){
    
    OutPut=sapply(marginal_effects(Modelo, Datos),mean)
    OutPut=data.frame("R4XCL_EfectosMarginales"= capture.output(OutPut))
    
  }else if(TipoOutput == 4){
    
    OutPut=data.frame("TEST"=A/B)
    
  }else if(TipoOutput == 5){
    
    OutPut = out$groups
    plot(out,variation="IQR")
    
  }else if(TipoOutput == 6){
    
    OutPut = out$means
    plot(out,variation="SD")
    
  }else{
    
    OutPut = "Revisar par�metros disponibles"
    
  }
  
  #-------------------------->>> 
  # [4] RESULTADO FINAL
  #-------------------------->>> 
  
  return(OutPut)  
  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

Detalle = "Estima un modelo ANOVA requerido por RS"

attr(RS_ANOVA, "description") = 
  list(
    Detalle,
    SetDatosX = "Variables INDEPENDIENTES cuantitativas",
    SetDatosY = "Variables DEPENDIENTES",
    TipoOutput= "0:Modelo, 1:Y Estimado, 2:Predicci�n, 3:Efectos Marginales, 4:Test , 5:Graf. Interquintiles , 6:Graf. Desv. ST ",
    SetDatosPredecir= "Computar datos fuera de muestra"
  )
