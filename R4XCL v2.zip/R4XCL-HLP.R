#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# TEST DE COINTEGRACION
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

R4XCL_Referencias <- function()
{

  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  

  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 

  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 

  tabla=rbind(
            c("TEMA", "RECURSO", 'ENLACE'),
            c("Econometr�a Series de Tiempo", "Libro Web", "https://nwfsc-timeseries.github.io/atsa-labs/chap-mss.html"),
            c("Econometr�a Series de Tiempo", "Libro Web", "https://bookdown.org/ccolonescu/RPoE4/intro.html"),
            c("mFilter","Documentaci�n R","https://cran.r-project.org/web/packages/mFilter/mFilter.pdf"),
            c("An�lisis de Componentes Principales","Web","https://rstudio-pubs-static.s3.amazonaws.com/585948_abd70a6fc3e24d4fad8944197bc5dd25.html"),
            c("Estad�stica Aplicada","Web","https://stats.idre.ucla.edu/other/dae/"),
            c("Econometr�a Series de Tiempo: VEC", "Libro Web", "https://www.r-econometrics.com/"),
            c("Journal","Journal of Statistical Software" , "https://www.jstatsoft.org/")
            )  
    
  OutPut  = tabla

  #-------------------------->>> 
  # [4] RESULTADO FINAL
  #-------------------------->>> 
  
  return(OutPut)  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

Detalle = "Algunas referencias que considero valiosas (Minor Bonilla)"

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# TEST DE RAIZ UNITARIA DF | PP
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++