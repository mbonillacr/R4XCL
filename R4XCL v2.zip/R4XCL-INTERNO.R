R4XCL_INT_DATOS= function(SetDatosX,SetDatosY=NULL)
{
  
  if (is.null(dim(SetDatosY))) {
  
    pX = ncol(SetDatosX)
    nombresX = paste0(SetDatosX[1,1:pX])
    DatosX  = SetDatosX[-1,]
    nX    = nrow(SetDatosX)-1
    DatosX = matrix(DatosX, nrow=nX, ncol=pX)
    colnames(DatosX)[1:pX] = nombresX[1:pX]
    Datos  = data.frame(DatosX)
  
  } else {
    
    pX = ncol(SetDatosX)
    pY = ncol(SetDatosY)
    
    nombresX = paste0(SetDatosX[1,1:pX])
    nombresY = paste0(SetDatosY[1,1])
    
    DatosY  = SetDatosY[-1,]  
    DatosX  = SetDatosX[-1,]
    
    nX    = nrow(SetDatosX)-1
    nY    = nX
    
    DatosY = matrix(DatosY, nrow=nY, ncol=pY)
    DatosX = matrix(DatosX, nrow=nX, ncol=pX)
    
    colnames(DatosY)[1:pY] = nombresY[1:pY]
    colnames(DatosX)[1:pX] = nombresX[1:pX]
    
    Datos  = data.frame(DatosY,DatosX)
    
  }
  
  FuncionInterna = list(Datos)
  return(FuncionInterna)
  
}

#-------------------------->>>   
# FIN 
#-------------------------->>>  

R4XCL_INT_FUNCION = function(SetDatosX,SetDatosY=NULL)
{
  
  pX = ncol(SetDatosX)
  pY = ncol(SetDatosY)
  pp = pY + pX
  
  nombresX = paste0(SetDatosX[1,1:pX])
  nombresY = paste0(SetDatosY[1,1])
  
  DatosY  = SetDatosY[-1,]  
  DatosX  = SetDatosX[-1,]
  
  nX    = nrow(SetDatosX)-1
  nY    = nX
  
  DatosY = matrix(DatosY, nrow=nY, ncol=pY)
  DatosX = matrix(DatosX, nrow=nX, ncol=pX)
  
  colnames(DatosY)[1:pY] = nombresY[1:pY]
  colnames(DatosX)[1:pX] = nombresX[1:pX]

  especificacion_A = ""
  especificacion_B = ""
  
  if (pp<1){
    
    especificacion_F = ""
    
  }else if (pp==2){
    
    especificacion_F = paste(nombresY[1],"~",nombresX[1],collapse = "")
    
  }else if (pp>2){
    
    especificacion_A = paste(nombresY,"~",nombresX[1],collapse = "")
    especificacion_B = paste("+" ,nombresX[2:pX] ,collapse  = "")
    especificacion_F = paste(
                              c(
                                especificacion_A,
                                especificacion_B
                                ),
                                collapse=""
                            )
  }  
  
  return(especificacion_F)
}

#-------------------------->>>   
# FIN 
#-------------------------->>>  

R4XCL_INT_CARPETA.RES = function()
{ 
            main_dir_orig   = "~/BERT2/"
            NombreCarpeta   = "RESULTADOS R4XCL"
            Ruta_Local_0    = paste0(main_dir_orig, NombreCarpeta)
            
            {
            output_dir <- file.path(Ruta_Local_0)
            if (!dir.exists(output_dir)){dir.create(output_dir)}
            }
}

#-------------------------->>>
# FIN 
#-------------------------->>>