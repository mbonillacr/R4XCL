#######  
CovidXCL1
#######
CovidXCL1<- function(){
  
  library(maps);

  pPathDATOS="C:/Users/mboni/Desktop/COVID/DATOS/"
  
  # MAPA 1 ----
  
  #install.packages("mapdeck")
  library(mapdeck)
  
  key="pk.eyJ1IjoibWlub3Jib25pbGxhZ29tZXoiLCJhIjoiY2s5cGF4dzN4MDk2MjNkb2RxbjNrcDZ2aiJ9.fSjAKiPHJyCbtkD6u7hRvA"
  
  ds_contagiocanton = readRDS(paste0(pPathDATOS,"st_contagiocanton.rds"))
  DS                = ds_contagiocanton[ds_contagiocanton$fecha=="2020-04-12",]
  DS$Legenda        = paste(DS$canton, " : ", DS$positivos)
  DS$Elevacion      = 1000*DS$positivos
  
  set_token(key)
  
  mapa=mapdeck( style = mapdeck_style("dark"),
                pitch = 60,
                location = c(-84.3, 9.5),
                zoom=10) 
  
  fig=mapa%>% add_column(data = DS
                     , lat = "latitud"
                     , lon = "longitud"
                     , elevation = "Elevacion"
                     , disk_resolution = 20
                     , radius = 1000
                     , tooltip = "Legenda"
                     , highlight_colour = "#AAFFFFFF"
                     #, fill_opacity = 0.6
                     ,auto_highlight = TRUE)
  dev.off();
  T;
  
  library(htmltools)
  HTMLOut <- "C:/Users/mboni/Documents/BERT2/functions/TEST.html"
  save_html(fig, HTMLOut)
}


#######  
CovidXCL2
#######

CovidXCL2 <- function(semilla,tipo){
  
  set.seed(semilla)  
  
  n=20
  
  X1=runif(n, min = 0, max = 25)
  
  X2=2*X1
  X3=3*x1
  
  Datos=cbind(X1,X2,X3)
  
  Datos1=data.frame("Resultado"= Datos)
  Datos2=data.frame("Valor de Pi"= pi)

  
  if (tipo == 0){
    
      Datos=data.frame(Datos1,Datos2)
  
    }else if(tipo == 1){
    
      Datos = data.frame(capture.output(summary(Datos1)))
  
    }else if(tipo == 2){
    
      BERT.graphics.device(cell=F);
      
      par(mfrow=c(2,2))
      
      plot(Datos[,1]);
      plot(Datos[,2]);
      plot(Datos[,3]);
      hist(Datos[,1]);
      
      dev.off();
      T
      
    }else if(tipo == 3){  
      
      library(plotly)
      # volcano is a numeric matrix that ships with R
      fig <- plot_ly(z = ~volcano)
      fig <- fig %>% add_surface()

      htmlwidgets::saveWidget(fig, "DesdeEXCEL.html")
      T
      
      }
  
}

attr(CovidXCL2, "description") <- list( 
  "Crean un set de datos aleatorios",
  semilla = "fija el valor para generaciones aleatorias identicas",
  tipo = "0: Set de datos, 1: Resumen, 2:Valores Extremos"
  )

#######  
CovidXCL3
#######

CovidXCL3 <- function(){
library(rpivotTable)
  pPathDATOS="C:/Users/mboni/Desktop/COVID/DATOS/"
  ds_contagiocanton = readRDS(paste0(pPathDATOS,"st_contagiocanton.rds"))
  DS                = ds_contagiocanton[ds_contagiocanton$fecha=="2020-04-12",]  
  
tPivote=rpivotTable(data = DS, 
            rendererName = "Table", width="100%", height="400px")

library(htmltools)
HTMLOut <- "C:/Users/mboni/Documents/BERT2/functions/tPivote.html"
save_html(tPivote, HTMLOut)

}

#
# draw a map from a list of countries and a list 
# of values, using a heat scale.  optionally add
# a title to the map.
#
# requires the `maps` package.
# 
draw.map <- function( countries, values, title ){
  
  library(maps);
  BERT.graphics.device(cell=T);
  
  # allow nulls in countries; map to values and ensure zeros.
  
  c2 <- unlist(countries[!is.na(countries)]);
  values <- as.numeric(values);
  values[is.na(values)] <- 0;
  v2 <- unlist(values[!is.na(countries)]);
  
  # for colors, reduce to a color space of 32 (?) levels. scale values.
  
  n <- 32;
  scaled.values <- round((1-((v2-min(v2))/(max(v2) - min(v2))))*(n-1))+1;
  heatcolors <- heat.colors(n);
  
  margins = c(0, 0, 0, 0);
  if( !missing(title)){ margins[3] <- .6; }
  
  # fill doesn't work properly (or at least as one would expect) 
  # when a country has multiple polygons, so do this in separate passes...
  
  # 1: space out the map
  par(mai=margins);
  map("world", c2, fill=F, lty=0);
  
  # 2: fill in countries
  sapply( c2, function(country){ 
    map( "world", country, fill=T, lty=0, add=T, 
         col=heatcolors[scaled.values[[which(c2==country)]]] );
  });
  
  # 3: draw lines on top
  map("world", c2, fill=F, col="#cccccc", add=T );
  
  # add title
  
  if(!missing(title)){ title( main=title, font.main=1 ); }
  
  dev.off();
  T;
}

#ML_Logit
####### 
ML_Logit
#######
MR_-Logit <- function(SetDatosY, SetDatosX)
{
  
  library(ResourceSelection)
  #library(InformationValue)
  
  #https://cran.r-project.org/web/packages/InformationValue/vignettes/InformationValue.html
  #http://statistics.ats.ucla.edu/stat/r/dae/logit.htm
  
  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  
  p = ncol(SetDatosX)
  
  nombresX=paste0(SetDatosX[1,1:p])
  nombresY=paste0(SetDatosY[1,1])
  
  DatosY=SetDatosY[-1,]  
  DatosX=SetDatosX[-1,]
  
  ObsX=nrow(SetDatosX)-1
  ObsY=ObsX
  
  DatosX = matrix(as.numeric(DatosX), nrow=ObsX, ncol=p)
  DatosY = matrix(as.numeric(DatosY), nrow=ObsY, ncol=1)
  
  Datos  = data.frame(DatosY,DatosX)
  
  pp=p+1
  colnames(Datos)[1]=nombresY[1]
  colnames(Datos)[2:pp]=nombresX[1:p]
  
  especificacion_A = paste(nombresY,"~",nombresX[1],collapse = "") ;
  especificacion_B = paste("+" ,nombresX[2:p],collapse = "") ;
  if (p==1){especificacion_B=""}
  
  especificacion= paste(c(especificacion_A,especificacion_B),collapse="");
  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
  OutPut_A <- glm(formula = especificacion, data = Datos, family = "binomial");
  
  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
  if (tipo == 0){
    
    OutPut = summary(OutPut_A)
    
  }else if(tipo == 1){
  
    OutPut   = OutPut_A$fitted.values

  }else if(tipo == 2){    
      
  #OutPut_C = NULL #InformationValue::optimalCutoff(Datos$Y,Y_Pred)
  
    OutPut = ResourceSelection::hoslem.test(Datos$Y, Y_Pred, 10)
  
  #OutPut_E = with(OutPut_B, pchisq(null.deviance - deviance, df.null - df.residual, lower.tail = FALSE))
  #OutPut_F = logLik(OutPut_A)
  #OutPut_G = AIC(OutPut_A)
  #OutPut_H = BIC(OutPut_A)
  #OutPut_I = confint(OutPut_A)  
    
    #OutPut = data.frame("Resultado"= capture.output(summary(OutPut_A)))
  
    }
  #A_Tab  = data.frame(
  #  "Y"= OutPut_A$y,
  # "Y.Estimado"= OutPut_A$fitted.values, 
  #  "Residuos"= OutPut_A$residuals
  #)
  
  # B_coef = data.frame(
  #   OutPut_B$coefficients,
  #   "CoefInt"=OutPut_I
  # )
  
  # B_Cov  = data.frame("Matriz Covarianza"=OutPut_B$cov.unscaled)
  
  #C_Opt  = data.frame(
  #"*****"="TEST",
  #"TestF.pValue"  =OutPut_E,
  #"HL.pValue"     =OutPut_D$p.value,                      
  #"LogL"          =OutPut_F,
  #"AIC"           =OutPut_G,
  #"BIC"           =OutPut_H,
  #"Corte.Optimo"  =OutPut_C
  #)
  
  #-------------------------->>> 
  # [4] RESULTADO FINAL
  #-------------------------->>> 
  
  message("FUNCIONA")
  
  return(OutPut)  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

attr(MR_Logit, "description" ) <- list( 
  "Estima el modelo de regresión para variable binaria",
  SetDatosX = "Variables INDEPENDIENTES",
  SetDatosY = "Variables DEPENDIENTES",
  TipoModelo= "0:Logit, 1:Probit",
  TipoOutput= "0:Estaditicos Generales, 1:Prob Estimada, 2: Z estimado")
####### 