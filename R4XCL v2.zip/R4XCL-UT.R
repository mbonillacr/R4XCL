#-------------------------->>> 
#  INCLUIR WordCloud
#-------------------------->>> 


#-------------------------->>> 
#  Crea DUMMIES
#-------------------------->>> 

UT_Dummies = function(SetDatosX,TipoOutput=0)
{
  
  library(dummies)

  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  
  p = ncol(SetDatosX)
  n = nrow(SetDatosX)-1
  
  nombresX=paste0(SetDatosX[1,1:p])

  DatosX=SetDatosX[-1,]
  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  

  
  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
  if (TipoOutput == 0){

    OutPut=dummies::dummy(DatosX)
    #OutPut = data.frame(A)
    
  }else if(TipoOutput == 1){
    
    OutPut = scale(matrix(as.numeric(DatosX),n,p), center = TRUE, scale = TRUE)
    OutPut = data.frame("R4XL_DatosNormalizados"= OutPut)
    
  }else if(TipoOutput == 2){    
    

    
  }else if(TipoOutput == 3){ 
    

    
  }else if(TipoOutput == 4){
    

    
  }else if(TipoOutput == 5){   
    

    
  }else if(TipoOutput > 5){     
    
    OutPut = "Revisar par�metros disponibles"
    
  } 
  #-------------------------->>> 
  # [4] RESULTADO FINAL
  #-------------------------->>> 
  
  return(OutPut)  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++
Detalle = "Estima un modelo de regresi�n para variable binaria (Y={0,1})"
attr(UT_Dummies, "description" ) = 
  list( 
        Detalle,
        SetDatosX = "Datos a procesar",
        TipoOutput= "0:Crea Dummies, 1:Normalizar, 2:, 3:, 4:"
      )

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# ArchivoExternoLRG                                +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

UT_ArchivoExternoLRG = function()
{
  require(svDialogs)
  require(tcltk)
  require(dplyr)
  
  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  

  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
  ListaFunciones=c("Resumen de Datos", "Selecci�n Muestral", "POR LLENAR CON ALGUN METODO")
  TipoDialogo = c("ok", "okcancel", "yesno", "yesnocancel")
  MSG1="Seleccione el archivo a cargar"
  
  dlg_message(message=MSG1, type = TipoDialogo[1] )

  pArchivo = tk_choose.files()  
  MSG2     = paste0("Archivo seleccionado: ",pArchivo," Desea Continuar?")
  msgBox   = dlg_message(message=MSG2, type = TipoDialogo[3] )
  
  if (msgBox$res == "no") {return(NULL)}
  
  SetDatosX=read.csv(pArchivo)
  p =ncol(SetDatosX)
  
  nombresX=paste0(SetDatosX[1,1:p])
  
  DatosX=SetDatosX[-1,]
  #n=nrow(SetDatosX)-1

  #DatosX = matrix(DatosX, nrow=n, ncol=p)

  colnames(DatosX)[1:p]= nombresX[1:p]
  
  message(class(DatosX))
  
  A = dlg_list(ListaFunciones)
  seleccionado=A$res
  
  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  
  if (seleccionado == "Resumen de Datos")
    
  {
    
    proceso="summary("
    A=eval(parse(text=paste0(proceso,"DatosX",")")))
    OutPut=capture.output(A)
    
  } else if(seleccionado == "Selecci�n Muestral") {
  
    a=dlg_input(message = "Cantidad de Elementos a Seleccionar")
    N=a$res
    proceso="dplyr::sample_n("
    A=eval(parse(text=paste0(proceso,"DatosX,",N,")")))
    OutPut=A 
  
} else if(seleccionado == "Histogramas de Datos Contenidos") {
  
  SetDatosX=as.numeric(SetDatosX)
  FX='hist'
  proceso=paste0("lapply(DatosX[2:p], FUN=",FX,")")
  
  #proceso="hist("
  #A=eval(parse(text=paste0(proceso,"as.numeric(SetDatosX[,c(1:p)])",")")))
  
  A=eval(parse(text=proceso))
  OutPut="Ver Gr�fico"
  
}
  
  #-------------------------->>> 
  # [4] RESULTADO FINAL
  #-------------------------->>> 
  
  return(OutPut)  
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++
Detalle = "Estima un modelo de regresi�n para variable binaria (Y={0,1})"
attr(UT_ArchivoExternoLRG, "description" ) = 
  list( 
    Detalle,
    TipoOutput= "0:Crea Dummies, 1:Normalizar, 2:, 3:, 4:"
  )

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# Instala Paquetes Necesarios para R4XCL              +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

UT_InstalaPaquetes <- function(PAQUETE1=NULL,PAQUETE2=NULL, PAQUETE3=NULL )
{  
  
  InstalarPaquetes =
    c(
      "corrplot","curl","data.table","dplyr","lmtest",
      "mapdeck","maps","margins","mboost",  "mFilter",  
      "readr", "ResourceSelection", "rlang", "rpart" ,  
      "rpart.plot", "rpivotTable", "sandwich", "stargazer",  
      "tseries", "tidyr", "vctrs", "VGAM", "zoo","agricolae",
      PAQUETE1,
      PAQUETE2,
      PAQUETE3
    )
  
  PaquetesPorInstalar <- setdiff(InstalarPaquetes, rownames(installed.packages()))
  message(PaquetesPorInstalar)
  
  if(length(PaquetesPorInstalar) > 0){install.packages(PaquetesPorInstalar, dependencies = TRUE)}
  
  return(PaquetesPorInstalar)
  
}

#-------------------------->>>   
# FIN 
#-------------------------->>>  
