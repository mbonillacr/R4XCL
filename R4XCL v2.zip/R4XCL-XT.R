
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# DISTANCIA                                            +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

FX_Distancias <- function(SetDatosX,
                          pEscalaDatos=1,
                          pTipoDistancia=1,
                          pPotenciaMinkowski=2)
    
  {

    #-------------------------->>>   
    # [1] PREPARACION DE DATOS Y PARAMETROS  
    #-------------------------->>>  

    DIR_ORIG = "~/BERT2/functions/"
    ARCHIVO  = paste0(DIR_ORIG,"R4XCL-INTERNO.R")
    FUENTE01 = file.path(ARCHIVO)
    source(FUENTE01)
    
    DT = R4XCL_INT_DATOS(SetDatosX)
    DT = data.frame(DT)
    P  = ncol(DT)
    N  = nrow(DT)
    DT = matrix(as.numeric(unlist(DT)), nrow=N, ncol=P)
    
    if (pEscalaDatos==1){
    DT.ESCALADO = scale(DT, center = TRUE, scale = TRUE)
    } else { DT.ESCALADO = DT}
    
    #-------------------------->>> 
    # [2] PROCEDIMIENTO ANALITICO
    #-------------------------->>> 
    
    TipoDistancia=c("euclidean", "maximum", "manhattan", "canberra", "binary","minkowski")
    
    #-------------------------->>> 
    # [3] PREPARACION DE RESULTADOS
    #-------------------------->>> 
  
    DISTANCIAS = as.matrix(
                           dist(
                                DT.ESCALADO, 
                                method = TipoDistancia[pTipoDistancia],
                                diag = TRUE, 
                                upper = TRUE
                                )
                           )
    
    OutPut = DISTANCIAS
    
    #_________________________________________________________________   
    # [4] RESULTADO FINAL
    #_________________________________________________________________
    
    return(OutPut)
    
  }

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

Detalle = "Calcula distancias entre individuos"

attr(FX_Distancias, "description") = 
  list(Detalle,
       SetDatosX = "Datos por Analizar",
       pEscalaDatos = "Normalizar Datos: 0-NO, 1-SI",
       pTipoDistancia= "1:Euclidea, 2:Maxima, 3: Manhattan, 4:Canberra, 5: Binaria, 6: Minkowski",
       pPotenciaMinkowski= "Potencia distancia Minkowski")


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# DISTANCIA                                            +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++

FX_Aleatorio <- function(
                         N,
                         Min=0,
                         Max=1,
                         Semilla=NULL,
                         Histograma=0
                         )
  
{
  
  #-------------------------->>>   
  # [1] PREPARACION DE DATOS Y PARAMETROS  
  #-------------------------->>>  
  

  
  #-------------------------->>> 
  # [2] PROCEDIMIENTO ANALITICO
  #-------------------------->>> 
  
  
  #-------------------------->>> 
  # [3] PREPARACION DE RESULTADOS
  #-------------------------->>> 
  set.seed(Semilla)
  Aleatorios = runif(N,Min,Max)
  
  if (Histograma==0)
    {OutPut =  Aleatorios}
  else
    {OutPut = hist(Aleatorios)} 
  
  #_________________________________________________________________   
  # [4] RESULTADO FINAL
  #_________________________________________________________________
  
  return(OutPut)
  
}


#BERNOULLI: n,p

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++    
# FIN DE PROCEDIMIENTO                                 +
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

Detalle = "Genera N datos aleatorios a partir de la Funcion de Distribuci�n elegida"

attr(FX_Aleatorio, "description") = 
  list(Detalle,
       N = "Cantidad de Datos a Generar",
       Min = "Valor M�nimo",
       Max = "Valor M�ximo",
       Semilla = "Semilla de generaci�n aleatoria (�til para re generar los mismos resultados)",
       Histograma= "0:NO, 1:SI, ")